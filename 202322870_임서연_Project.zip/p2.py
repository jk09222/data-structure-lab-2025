# 프로젝트 문제 2번
input = ")))()"

def problem2(input):
    # 이 곳에 코드를 작성하세요.
    # 입력 힌트
    for char in input:
        print(char)
        
    open_needed = 0  # 앞에 더 필요한 '(' 수
    balance = 0      # 여는 괄호 개수 - 닫는 괄호 개수

    for char in input:
        if char == '(':
            balance += 1
        else:  # char == ')'
            if balance > 0:
                balance -= 1
            else:
                open_needed += 1

    result = open_needed + balance
    return result


result = problem2(input)

assert result == 3
print("정답입니다.")
